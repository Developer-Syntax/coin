# RollerCoin Mobile Proguard Rules
